# Changelog

## Unreleased



## 1.1.1 (2017-08-14)

 - Removed protocol from css links (#1)

## 1.1.0 (2016-11-21)

 - Adds a Github button

## 1.0.0 (2016-11-20)

 - Initial import
